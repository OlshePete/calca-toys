The font accelerates the process of adding inscriptions and eliminates the need to redraw the same letters every time. The lettering is based on a simple felt-tip pen. The lines have minimal contrast and are not meant to be perfect.

A simple and uncomplicated design goes great with a happy holiday mood. The font is suitable for small postcard texts, social media images, invitations, branding, mockups, packaging, ads, and captions.

The TS Remarker typeface consists of 4 fonts: 2 upright (normal for regular lettering and alternative for a more colorful impression) and 2 italic.

The Regular style can be downloaded and used in commercial projects for free.

Buy full version here:
https://www.myfonts.com/fonts/vitaliy-tsygankov/ts-remarker/

Appreciate and follow:
https://www.behance.net/limostudio